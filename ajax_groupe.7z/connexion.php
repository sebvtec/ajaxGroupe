<?php
	session_start();
	$bdd = new PDO('mysql:host=localhost;dbname=ajaxgroupe;charset=utf8', 'root', '');

?>